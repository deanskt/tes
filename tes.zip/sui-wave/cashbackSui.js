import { getFullnodeUrl, SuiClient } from "@mysten/sui.js/client";
import { Ed25519Keypair } from "@mysten/sui.js/keypairs/ed25519";
import { TransactionBlock } from "@mysten/sui.js/transactions";
import { getCoinOfValue } from "@polymedia/suits";

const client = new SuiClient({
  url: getFullnodeUrl("mainnet"),
});

function calculateBalance(totalBalance, divider) {
  return Number(totalBalance) / Math.pow(10, divider);
}

function reverseCalculateBalance(balance, multiplier) {
  return balance * Math.pow(10, multiplier);
}

const sendTransaction = (client, bytes, signature) =>
  new Promise(async (resolve, reject) => {
    try {
      await client.dryRunTransactionBlock({
        transactionBlock: bytes,
      });
      const result = await client.executeTransactionBlock({
        signature: signature,
        transactionBlock: bytes,
        requestType: "WaitForLocalExecution",
        options: {
          showEffects: true,
        },
      });
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });

const main = async () => {
  const gasBudget = "1500000";
  const mnemonic = "";
  const keypair = Ed25519Keypair.deriveKeypair(mnemonic);
  const suiAddress = keypair.getPublicKey().toSuiAddress();

  const oceanBalance = await client.getBalance({
    owner: suiAddress,
    coinType:
      "0xa8816d3a6e3136e86bc2873b1f94a15cadc8af2703c075f2d546c2ae367f4df9::ocean::OCEAN",
  });
  const oceanBalanceFormatted = calculateBalance(oceanBalance.totalBalance, 9);

  const suiBalance = await client.getBalance({
    owner: suiAddress,
    coinType: "0x2::sui::SUI",
  });

  const suiBalanceFormatted = calculateBalance(suiBalance.totalBalance, 9);

  console.log(
    Address : ${suiAddress} | OCEAN : ${oceanBalanceFormatted} OCEAN | SUI : ${suiBalanceFormatted} SUI
  );
  console.log();

  while (true) {
    const txTfResult = new TransactionBlock();
    const [coin] = await getCoinOfValue(
      client,
      txTfResult,
      suiAddress,
      "0xa8816d3a6e3136e86bc2873b1f94a15cadc8af2703c075f2d546c2ae367f4df9::ocean::OCEAN",
      0
    );
    txTfResult.transferObjects(
      [coin],
      txTfResult.pure(
        "0x0000000000000000000000000000000000000000000000000000000000000000"
      )
    );
    txTfResult.setGasBudget(gasBudget);
    txTfResult.setSender(suiAddress);
    let result = await client.devInspectTransactionBlock({
      transactionBlock: txTfResult,
      sender: suiAddress,
    });
    if (result && result.effects) {
      let totalGasUsed = parseInt(0);
      for (const key in result.effects.gasUsed) {
        totalGasUsed += parseInt(result.effects.gasUsed[key]);
      }
      console.log(Estimate Gas Fee: ${calculateBalance(totalGasUsed, 9)} SUI);
      const limitGasLimit = reverseCalculateBalance(0.01, 9);
      if (totalGasUsed >= limitGasLimit) {
        const { bytes, signature } = await txTfResult.sign({
          client,
          signer: keypair,
        });
        const txTfResults = await sendTransaction(client, bytes, signature);
        if (txTfResults.effects.status.status === "success") {
          console.log(
            Transfer Success | https://suiscan.xyz/mainnet/tx/${txTfResults.effects.transactionDigest}
          );
        } else {
          console.log(Transfer Failed);
        }
      } else {
        console.log(Lower than 0.01 SUI);
        console.log();
        break;
      }
    } else {
      console.log(Transaction Failed);
      console.log();
      break;
    }

    console.log();
  }

  const suiBalanceAfter = await client.getBalance({
    owner: suiAddress,
    coinType: "0x2::sui::SUI",
  });

  const suiBalanceAfterFormatted = calculateBalance(
    suiBalanceAfter.totalBalance,
    9
  );
  console.log(SUI Balance After : ${suiBalanceAfterFormatted} SUI);
};

main();